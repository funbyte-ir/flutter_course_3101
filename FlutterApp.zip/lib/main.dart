import 'package:flutter/material.dart';
import 'package:flutter_application_1/calculator.dart';
import 'package:flutter_application_1/home_page.dart';

void main() {
  runApp(
    MaterialApp(
      home: Calculator(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: "FunByte",
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.indigo.shade900,
      ),
      themeMode: ThemeMode.dark,
    ),
  );
}
