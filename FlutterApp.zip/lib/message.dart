class Message {
  String title;
  String subtitle;
  String time;

  Message(this.title, this.subtitle, this.time);
}
